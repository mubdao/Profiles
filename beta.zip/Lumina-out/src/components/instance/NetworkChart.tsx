import { useEffect, useMemo, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { X } from "lucide-react";
import { usePingRecords } from "@/hooks/useRecords";
import { useNode } from "@/hooks/useNode";
import { usePreferences } from "@/hooks/usePreferences";
import { InstancePanel } from "./InstancePanel";
import {
  formatAxisTime,
  formatTooltipTime,
  toChartSeconds,
  buildChartTicks,
} from "./chartShared";
import {
  cutPeakValues,
  detectTypicalIntervalMs,
  insertMetricGapSentinels,
} from "./chartData";
import type { TimedMetricPoint } from "./chartData";

const LOSS_COLOR = "hsl(45, 100%, 60%)";

function colorForTask(index: number) {
  const colors = ["#5d88ff", "#61c08f", "#a35cf5", "#f1873d", "#d4a54a"] as const;
  return colors[index % colors.length];
}

function delayTone(ms: number | null): string | undefined {
  if (ms == null) return undefined;
  if (ms < 100) return "var(--status-success)";
  if (ms < 200) return "var(--status-warning)";
  return "var(--status-error)";
}

function lossTone(pct: number): string {
  if (pct < 1) return "var(--status-success)";
  if (pct < 5) return "var(--status-warning)";
  return "var(--status-error)";
}

function jitterTone(value: number): string {
  if (value < 0.25) return "var(--status-success)";
  if (value < 0.5) return "var(--status-warning)";
  return "var(--status-error)";
}

function calcJitter(delays: number[]): number {
  const window = delays.filter((d) => d > 0).slice(-60);
  if (window.length < 2) return 0;
  const sorted = [...window].sort((a, b) => a - b);
  const p50 = sorted[Math.floor(sorted.length * 0.5)];
  const p95 = sorted[Math.min(Math.floor(sorted.length * 0.95), sorted.length - 1)];
  const diff = p95 - p50;
  const k = 30;
  return diff / (diff + k);
}

// Custom tooltip for recharts
function NetworkTooltipContent({
  active,
  payload,
  label,
  isSingle,
  seriesMeta,
  taskLabels,
  rangeHours = 0,
}: {
  active?: boolean;
  payload?: Array<{ value: number | null; dataKey: string }>;
  label?: number;
  isSingle: boolean;
  seriesMeta: Array<{ id: number; color: string }>;
  taskLabels: Map<number, string>;
  rangeHours?: number;
}) {
  if (!active || !payload || payload.length === 0 || label == null) return null;

  return (
    <div className="instance-chart-tooltip" style={{ position: "static", left: "unset", top: "unset" }}>
      <div className="instance-chart-tooltip-time">{formatTooltipTime(label, rangeHours)}</div>
      {seriesMeta.map((meta) => {
        const key = isSingle ? "delay" : String(meta.id);
        const entry = payload.find((p) => p.dataKey === key);
        const value = entry?.value ?? null;
        return (
          <div key={meta.id} className="instance-chart-tooltip-row">
            <span className="instance-chart-tooltip-dot" style={{ background: meta.color }} />
            <span>{taskLabels.get(meta.id) ?? `任务 #${meta.id}`}</span>
            <strong>
              {value == null ? "—" : value === 0 ? "<1 ms" : `${value.toFixed(1)} ms`}
            </strong>
          </div>
        );
      })}
      {isSingle && (() => {
        const lossEntry = payload.find((p) => p.dataKey === "loss");
        const loss = lossEntry?.value ?? null;
        return loss != null ? (
          <div className="instance-chart-tooltip-row">
            <span className="instance-chart-tooltip-dot" style={{ background: LOSS_COLOR }} />
            <span>丢包率</span>
            <strong>{`${Number(loss).toFixed(0)}%`}</strong>
          </div>
        ) : null;
      })()}
    </div>
  );
}

export function NetworkChart({
  uuid,
  hours,
  active = true,
}: {
  uuid: string;
  hours: number;
  active?: boolean;
}) {
  const { data, isLoading } = usePingRecords(uuid, hours, active);
  const node = useNode(uuid, active);
  const { resolvedAppearance } = usePreferences();
  const isDark = resolvedAppearance === "dark";
  const gridColor = isDark ? "rgba(255,255,255,0.065)" : "rgba(0,0,0,0.08)";
  const textColor = isDark ? "#a5a5aa" : "#52525b";

  const WIDE_CHART_HEIGHT = 340;

  const [activeCharts, setActiveCharts] = useState<number[]>([]);
  const [peakEnabled, setPeakEnabled] = useState(false);

  const tasks = useMemo(
    () => [...(data?.tasks ?? [])].sort((a, b) => a.id - b.id),
    [data],
  );

  const taskLabels = useMemo(() => {
    const counts = new Map<string, number>();
    for (const task of tasks) {
      const label = task.name || `任务 #${task.id}`;
      counts.set(label, (counts.get(label) ?? 0) + 1);
    }
    return new Map(
      tasks.map((task) => {
        const base = task.name || `任务 #${task.id}`;
        const label = (counts.get(base) ?? 0) > 1 ? `${base} #${task.id}` : base;
        return [task.id, label] as const;
      }),
    );
  }, [tasks]);

  const taskColors = useMemo(
    () => new Map(tasks.map((task, index) => [task.id, colorForTask(index)] as const)),
    [tasks],
  );

  useEffect(() => {
    setActiveCharts([]);
  }, [uuid]);

  useEffect(() => {
    setActiveCharts((prev) => {
      const valid = new Set(tasks.map((task) => task.id));
      const next = prev.filter((id) => valid.has(id));
      return next.length === prev.length ? prev : next;
    });
  }, [tasks]);

  const taskPoints = useMemo(() => {
    const map = new Map<number, Array<{ time: number; delay: number | null; loss: number }>>();
    for (const task of tasks) map.set(task.id, []);
    for (const record of data?.records ?? []) {
      const bucket = map.get(record.task_id);
      if (!bucket) continue;
      const time = toChartSeconds(record.time);
      if (time <= 0) continue;
      bucket.push({
        time,
        delay: record.value > 0 ? record.value : null,
        loss: record.value > 0 ? 0 : 100,
      });
    }
    for (const points of map.values()) points.sort((a, b) => a.time - b.time);
    return map;
  }, [data, tasks]);

  const taskStats = useMemo(
    () =>
      tasks.map((task) => {
        const points = taskPoints.get(task.id) ?? [];
        const delays = points.map((p) => p.delay).filter((d): d is number => d != null);
        let lastDelay: number | null = null;
        for (let i = points.length - 1; i >= 0; i--) {
          if (points[i].delay != null) {
            lastDelay = points[i].delay;
            break;
          }
        }
        const total = points.length;
        const lost = points.filter((p) => p.delay == null).length;
        const loss = total > 0 ? (lost / total) * 100 : task.loss;
        const jitter = calcJitter(delays);
        return { task, lastDelay, loss, jitter };
      }),
    [tasks, taskPoints],
  );

  const plottedIds = useMemo(
    () => (activeCharts.length > 0 ? activeCharts : tasks.map((task) => task.id)),
    [activeCharts, tasks],
  );

  const isSingle = activeCharts.length === 1;

  // Build recharts-compatible data array
  const chartData = useMemo<Array<Record<string, number | null>>>(() => {
    if (tasks.length === 0) return [];

    if (isSingle) {
      const id = activeCharts[0];
      let points: TimedMetricPoint[] = (taskPoints.get(id) ?? []).map((p) => ({
        time: p.time,
        delay: p.delay,
        loss: p.loss,
      }));
      if (points.length === 0) return [];
      if (peakEnabled) points = cutPeakValues(points, ["delay"]);
      const interval = detectTypicalIntervalMs(points.map((p) => p.time), 60);
      points = insertMetricGapSentinels(points, {
        intervals: new Map([["delay", interval]]),
        defaultInterval: interval,
        matchToleranceRatio: 0.25,
      });
      return points.map((p) => ({
        time: p.time,
        delay: (p.delay ?? null) as number | null,
        loss: (p.loss ?? null) as number | null,
      }));
    }

    // Multi-task: merge onto a shared timeline
    const intervals = tasks
      .map((task) => task.interval)
      .filter((v): v is number => typeof v === "number" && v > 0);
    const fallbackInterval =
      intervals.length > 0
        ? Math.min(...intervals)
        : detectTypicalIntervalMs(
            (data?.records ?? []).map((r) => toChartSeconds(r.time)).filter((t) => t > 0),
            60,
          );
    const tolerance = Math.min(6, Math.max(0.8, fallbackInterval * 0.25));

    const plotted = new Set(plottedIds);
    const merged = [...(data?.records ?? [])]
      .map((record) => ({ record, time: toChartSeconds(record.time) }))
      .filter(({ record, time }) => time > 0 && plotted.has(record.task_id))
      .sort((a, b) => a.time - b.time);

    const anchors: number[] = [];
    const pointMap = new Map<number, TimedMetricPoint>();
    for (const { record, time } of merged) {
      let anchor = time;
      for (const existing of anchors) {
        if (Math.abs(existing - time) <= tolerance) {
          anchor = existing;
          break;
        }
      }
      if (anchor === time) anchors.push(anchor);
      const current = pointMap.get(anchor) ?? { time: anchor };
      current[String(record.task_id)] = record.value > 0 ? record.value : null;
      pointMap.set(anchor, current);
    }

    const keys = plottedIds.map((id) => String(id));
    let points = [...pointMap.values()].sort((a, b) => a.time - b.time);
    if (peakEnabled && keys.length > 0) points = cutPeakValues(points, keys);
    points = insertMetricGapSentinels(points, {
      intervals: new Map(
        tasks
          .filter((task) => typeof task.interval === "number" && task.interval > 0)
          .map((task) => [String(task.id), task.interval] as const),
      ),
      defaultInterval: fallbackInterval,
      matchToleranceRatio: 0.25,
    });

    return points.map((p) => {
      const row: Record<string, number | null> = { time: p.time };
      for (const key of keys) {
        row[key] = (p[key] ?? null) as number | null;
      }
      return row;
    });
  }, [tasks, isSingle, activeCharts, taskPoints, peakEnabled, plottedIds, data]);

  const seriesMeta = useMemo(
    () =>
      isSingle
        ? [{ id: activeCharts[0], color: taskColors.get(activeCharts[0]) ?? colorForTask(0) }]
        : plottedIds.map((id, index) => ({ id, color: taskColors.get(id) ?? colorForTask(index) })),
    [isSingle, activeCharts, plottedIds, taskColors],
  );

  const toggleChart = (taskId: number) => {
    setActiveCharts((prev) =>
      prev.includes(taskId) ? prev.filter((id) => id !== taskId) : [...prev, taskId],
    );
  };

  if (isLoading) {
    return <section className="instance-panel h-[260px] animate-pulse" aria-busy />;
  }

  if (!data?.records.length || tasks.length === 0) {
    return (
      <InstancePanel title="网络监控">
        <div className="instance-empty">暂无延迟记录</div>
      </InstancePanel>
    );
  }

  return (
    <section className="instance-panel network-chart">
      <header className="network-chart-header">
        <div className="network-chart-meta">
          <div className="network-chart-name">{node?.name || "网络监控"}</div>
          <div className="network-chart-controls">
            <button
              type="button"
              className="instance-toggle-button instance-switch-button"
              data-active={peakEnabled ? "true" : "false"}
              onClick={() => setPeakEnabled((v) => !v)}
              aria-pressed={peakEnabled}
              title="Lightly smooth spike values, affects chart display only"
            >
              <span className="instance-switch-copy">Smooth spikes</span>
              <span className="instance-switch-track" aria-hidden>
                <span className="instance-switch-thumb" />
              </span>
              <span className="instance-switch-state">{peakEnabled ? "On" : "Off"}</span>
            </button>
          </div>
        </div>
        <div className="network-monitor-buttons">
          {taskStats.map(({ task, lastDelay, loss, jitter }) => (
            <button
              key={task.id}
              type="button"
              className="network-monitor-button"
              data-active={activeCharts.includes(task.id) ? "true" : "false"}
              aria-pressed={activeCharts.includes(task.id)}
              onClick={() => toggleChart(task.id)}
              style={{ "--monitor-accent": taskColors.get(task.id) } as React.CSSProperties}
            >
              <span className="network-monitor-name">{taskLabels.get(task.id) ?? `Task #${task.id}`}</span>
              <span className="network-monitor-delay">
                <span style={{ color: delayTone(lastDelay) }}>
                  {lastDelay == null ? "--" : lastDelay === 0 ? "<1" : lastDelay.toFixed(1)}
                </span>
                <span className="network-monitor-unit"> ms</span>
              </span>
              <span className="network-monitor-sub">
                Loss <span style={{ color: lossTone(loss) }}>{loss.toFixed(1)}%</span>
                {"  "}Jitter <span style={{ color: jitterTone(jitter) }}>{jitter.toFixed(2)}</span>
              </span>
            </button>
          ))}
        </div>
      </header>

      <div className="network-chart-body">
        {activeCharts.length > 0 && (
          <button
            type="button"
            className="network-chart-clear"
            onClick={() => setActiveCharts([])}
          >
            <X size={12} />
            Clear ({activeCharts.length})
          </button>
        )}
        <div className="instance-chart-wrap is-large">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={WIDE_CHART_HEIGHT}>
              <LineChart
                data={chartData}
                margin={{ top: 4, right: 8, bottom: 4, left: 0 }}
              >
                <CartesianGrid stroke={gridColor} strokeWidth={1} />
                <XAxis
                  dataKey="time"
                  type="number"
                  domain={["dataMin", "dataMax"]}
                  scale="time"
                  ticks={buildChartTicks(chartData as Array<{ time: number }>, hours)}
                  tickFormatter={(v) => formatAxisTime(v, hours)}
                  tick={{ fill: textColor, fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  height={24}
                />
                {/* Delay Y axis (left) */}
                <YAxis
                  yAxisId="y"
                  tick={{ fill: textColor, fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => v === 0 ? "" : `${Math.round(v)}ms`}
                  tickCount={4}
                  width={44}
                />
                {/* Loss Y axis (right) — only in single mode */}
                {isSingle && (
                  <YAxis
                    yAxisId="loss"
                    orientation="right"
                    domain={[0, 100]}
                    tick={{ fill: textColor, fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => `${Math.round(v)}%`}
                    tickCount={4}
                    width={36}
                  />
                )}
                <Tooltip
                  content={
                    <NetworkTooltipContent
                      isSingle={isSingle}
                      seriesMeta={seriesMeta}
                      taskLabels={taskLabels}
                      rangeHours={hours}
                    />
                  }
                />
                {/* Delay lines */}
                {seriesMeta.map((meta) => {
                  const dataKey = isSingle ? "delay" : String(meta.id);
                  return (
                    <Line
                      key={meta.id}
                      yAxisId="y"
                      type="linear"
                      dataKey={dataKey}
                      stroke={meta.color}
                      strokeWidth={1}
                      fill="none"
                      dot={false}
                      isAnimationActive={false}
                      connectNulls={false}
                      style={{ shapeRendering: "crispEdges", vectorEffect: "non-scaling-stroke" }}
                    />
                  );
                })}
                {/* Packet loss line — only in single mode */}
                {isSingle && (
                  <Line
                    yAxisId="loss"
                    type="linear"
                    dataKey="loss"
                    stroke={LOSS_COLOR}
                    strokeWidth={1}
                    fill="none"
                    dot={false}
                    isAnimationActive={false}
                    connectNulls={true}
                    style={{ shapeRendering: "crispEdges", vectorEffect: "non-scaling-stroke" }}
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="instance-empty">暂无可显示的监控数据</div>
          )}
        </div>
      </div>
    </section>
  );
}
