import { useEffect, useRef, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { ChevronLeft } from "lucide-react";
import { useNode } from "@/hooks/useNode";
import { Flag, resolveFlagCode } from "@/components/ui/Flag";
import { formatBytes, formatUptimeDays } from "@/utils/format";

function formatClock(ts: number): string {
  if (!ts || ts <= 0) return "—";
  return new Intl.DateTimeFormat("zh-CN", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(ts);
}

function formatBootTime(uptimeSeconds: number): string {
  if (!uptimeSeconds || uptimeSeconds <= 0) return "—";
  const bootMs = Date.now() - uptimeSeconds * 1000;
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(bootMs);
}

export function InstanceOverview({
  uuid,
  onNodeReady,
}: {
  uuid: string;
  onNodeReady?: () => (() => void) | void;
}) {
  const node = useNode(uuid);
  const hasAlignedOnReadyRef = useRef(false);

  useEffect(() => {
    hasAlignedOnReadyRef.current = false;
  }, [uuid]);

  useEffect(() => {
    if (!node || hasAlignedOnReadyRef.current) return;
    hasAlignedOnReadyRef.current = true;
    return onNodeReady?.();
  }, [node, onNodeReady]);

  const isOnline = node?.online;
  const uptime = node ? formatUptimeDays(node.uptime) : null;
  const cpuLabel = node
    ? `${node.cpu_name || "—"}${node.cpu_cores > 0 ? ` (x${node.cpu_cores})` : ""}`
    : "—";

  return (
    <div className="instance-overview">
      <Link to="/" className="instance-page-back">
        <ChevronLeft size={14} />
        返回
      </Link>
      {node && (
        <section className="instance-panel instance-overview-panel">
          <div className="instance-overview-cards">
            <InfoCard
              label="状态"
              value={
                <span
                  className="instance-overview-status"
                  data-online={isOnline ? "true" : "false"}
                >
                  {isOnline ? "Online" : "Offline"}
                </span>
              }
            />
            {isOnline && uptime && (
              <InfoCard
                label="运行时长"
                value={uptime.unit ? `${uptime.value} ${uptime.unit}` : uptime.value}
              />
            )}
            {node.arch && <InfoCard label="架构" value={node.arch} />}
            {node.mem_total > 0 && (
              <InfoCard label="内存" value={formatBytes(node.mem_total)} />
            )}
            {node.disk_total > 0 && (
              <InfoCard label="磁盘" value={formatBytes(node.disk_total)} />
            )}
            {node.region && (
              <InfoCard
                label="地区"
                value={
                  <span className="instance-overview-region">
                    {resolveFlagCode(node.region) && (
                      <span>{resolveFlagCode(node.region)}</span>
                    )}
                    <Flag region={node.region} size={13} />
                  </span>
                }
              />
            )}
            {node.virtualization && (
              <InfoCard label="虚拟化" value={node.virtualization} />
            )}
            {node.os && <InfoCard wide label="操作系统" value={node.os} />}
            {node.cpu_name && <InfoCard wide label="CPU" value={cpuLabel} />}
            <InfoCard
              label="Load"
              value={`${node.load1.toFixed(2)} | ${node.load5.toFixed(2)} | ${node.load15.toFixed(2)}`}
            />
            <InfoCard label="上传" value={`↑ ${formatBytes(node.trafficUp)}`} />
            <InfoCard label="下载" value={`↓ ${formatBytes(node.trafficDown)}`} />
            {node.uptime > 0 && (
              <InfoCard
                label="启动时间"
                value={formatBootTime(node.uptime)}
              />
            )}
            <InfoCard
              label="最后上报时间"
              value={formatClock(node.updatedAt)}
            />
          </div>
        </section>
      )}
    </div>
  );
}

function InfoCard({
  label,
  value,
  wide,
}: {
  label: string;
  value: ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="instance-overview-card" data-wide={wide ? "true" : "false"}>
      <p className="instance-overview-card-label">{label}</p>
      <div className="instance-overview-card-value">{value}</div>
    </div>
  );
}
