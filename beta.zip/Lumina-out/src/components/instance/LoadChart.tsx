import {
  memo,
  useEffect,
  useMemo,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  Cpu,
  Gauge,
  HardDrive,
  MemoryStick,
  Network,
  Workflow,
} from "lucide-react";
import { useLoadRecords } from "@/hooks/useRecords";
import { useNode } from "@/hooks/useNode";
import { InstancePanel } from "./InstancePanel";
import {
  formatTooltipTime,
  formatAxisTime,
  toChartSeconds,
  buildChartTicks,
} from "./chartShared";
import { fillMissingMetricPoints, interpolateMetricGaps } from "./chartData";
import { formatBytes, formatTrafficRateLabel } from "@/utils/format";
import { usePreferences } from "@/hooks/usePreferences";

const CHART_COLORS = {
  cpu: "#5d88ff",
  memory: "#a35cf5",
  disk: "#f1873d",
  success: "#61c08f",
  warning: "#d4a54a",
} as const;

const LOAD_HISTORY_SAMPLE_LIMIT = 360;
const LOAD_HISTORY_RENDER_LIMIT = 720;
const REALTIME_HISTORY_SEED_LIMIT = 120;
const REALTIME_SAMPLE_LIMIT = 600;

const CPU_KEYS = ["cpu"];
const CPU_COLORS = [CHART_COLORS.cpu];
const MEMORY_KEYS = ["ram", "swap"];
const MEMORY_COLORS = [CHART_COLORS.memory, CHART_COLORS.warning];
const DISK_KEYS = ["disk"];
const DISK_COLORS = [CHART_COLORS.disk];
const NETWORK_KEYS = ["netIn", "netOut"];
const NETWORK_COLORS = [CHART_COLORS.success, CHART_COLORS.cpu];
const CONNECTION_KEYS = ["connections", "udp"];
const CONNECTION_COLORS = [CHART_COLORS.memory, CHART_COLORS.cpu];
const PROCESS_KEYS = ["process"];
const PROCESS_COLORS = [CHART_COLORS.warning];

const SERIES_LABELS: Record<string, string> = {
  cpu: "CPU",
  ram: "内存",
  swap: "Swap",
  disk: "磁盘",
  diskBytes: "磁盘",
  netIn: "下行",
  netOut: "上行",
  connections: "TCP",
  udp: "UDP",
  process: "进程",
  load: "负载",
};

const LOAD_INTERPOLATE_KEYS = [
  "cpu",
  "ram",
  "swap",
  "disk",
  "diskBytes",
  "netIn",
  "netOut",
  "connections",
  "udp",
  "process",
  "load",
];

interface ChartPoint {
  time: number;
  [key: string]: number | null;
}

function getHistoryRenderLimit(hours: number) {
  if (hours <= 4) return LOAD_HISTORY_SAMPLE_LIMIT;
  return LOAD_HISTORY_RENDER_LIMIT;
}

function downsamplePoints(points: ChartPoint[], limit: number) {
  if (points.length <= limit || limit < 2) return points;

  const result: ChartPoint[] = [];
  const lastIndex = points.length - 1;
  const step = lastIndex / (limit - 1);
  let previousIndex = -1;

  for (let index = 0; index < limit; index += 1) {
    const sourceIndex = Math.min(lastIndex, Math.round(index * step));
    if (sourceIndex === previousIndex) continue;
    result.push(points[sourceIndex]);
    previousIndex = sourceIndex;
  }

  return result;
}

function getSeriesLabel(key: string) {
  return SERIES_LABELS[key] ?? key;
}

function pointFromNode(node: NonNullable<ReturnType<typeof useNode>>): ChartPoint {
  return {
    time: Date.now() / 1000,
    cpu: node.cpuPct,
    ram: node.ramTotal > 0 ? (node.ramUsed / node.ramTotal) * 100 : 0,
    swap: node.swapTotal > 0 ? (node.swapUsed / node.swapTotal) * 100 : 0,
    disk: node.diskTotal > 0 ? (node.diskUsed / node.diskTotal) * 100 : 0,
    diskBytes: node.diskUsed,
    netIn: node.netDown,
    netOut: node.netUp,
    connections: node.connectionsTcp,
    udp: node.connectionsUdp,
    process: node.process,
    load: node.load1,
  };
}

function formatTooltipValue(key: string, value: number | null | undefined, unit: string) {
  if (value == null || !Number.isFinite(value)) return "—";
  if (key === "netIn" || key === "netOut") return formatTrafficRateLabel(value);
  if (unit === "%") return `${value.toFixed(2)}%`;
  if (key === "process" || key === "connections" || key === "udp") return `${Math.round(value)}`;
  return value.toFixed(2);
}

function formatPercentAxisValue(value: number) {
  return `${Math.round(value)}%`;
}

function formatNetworkAxisValue(value: number) {
  if (!Number.isFinite(value) || value <= 0) return "";
  const bps = value * 8;
  if (bps >= 1_000_000_000) return `${(bps / 1_000_000_000).toFixed(1)}G`;
  if (bps >= 1_000_000) return `${(bps / 1_000_000).toFixed(1)}M`;
  if (bps >= 1_000) return `${Math.round(bps / 1_000)}K`;
  return `${Math.round(bps)}`;
}

function formatCountAxisValue(value: number) {
  return `${Math.round(value)}`;
}

// Custom recharts tooltip component
function ChartTooltipContent({
  active,
  payload,
  label,
  keys,
  colors,
  unit,
  rangeHours,
}: {
  active?: boolean;
  payload?: Array<{ value: number | null; dataKey: string }>;
  label?: number;
  keys: string[];
  colors: string[];
  unit: string;
  rangeHours: number;
}) {
  if (!active || !payload || payload.length === 0 || label == null) return null;

  return (
    <div className="instance-chart-tooltip" style={{ position: "static", left: "unset", top: "unset" }}>
      <div className="instance-chart-tooltip-time">{formatTooltipTime(label, rangeHours)}</div>
      {keys.map((key, index) => {
        const entry = payload.find((p) => p.dataKey === key);
        const value = entry?.value ?? null;
        return (
          <div key={key} className="instance-chart-tooltip-row">
            <span
              className="instance-chart-tooltip-dot"
              style={{ background: colors[index] ?? colors[0] }}
            />
            <span>{getSeriesLabel(key)}</span>
            <strong>{formatTooltipValue(key, value, unit)}</strong>
          </div>
        );
      })}
    </div>
  );
}

const ChartCard = memo(function ChartCard({
  icon,
  title,
  value,
  points,
  keys,
  colors,
  height,
  resolvedAppearance,
  rangeHours,
  unit = "",
  spanGaps,
  axisKind,
}: {
  icon: ReactNode;
  title: string;
  value: ReactNode;
  points: ChartPoint[];
  keys: string[];
  colors: string[];
  height: number;
  resolvedAppearance: "light" | "dark";
  rangeHours: number;
  unit?: string;
  spanGaps?: boolean;
  axisKind?: "default" | "percent" | "network" | "count";
}) {
  const isDark = resolvedAppearance === "dark";
  const gridColor = isDark ? "rgba(255,255,255,0.065)" : "rgba(0,0,0,0.08)";
  const textColor = isDark ? "#a5a5aa" : "#52525b";

  const yTickFormatter = (value: number) => {
    if (axisKind === "percent") return formatPercentAxisValue(value);
    if (axisKind === "network") return formatNetworkAxisValue(value);
    if (axisKind === "count") return formatCountAxisValue(value);
    return value === 0 ? "" : `${Math.round(value)}${unit}`;
  };

  const xTickFormatter = (value: number) => formatAxisTime(value, rangeHours);
  const xTicks = buildChartTicks(points, rangeHours);

  return (
    <div
      className="instance-chart-card"
      style={{ "--chart-accent": colors[0] } as CSSProperties}
    >
      <header className="instance-chart-card-head">
        <div className="instance-panel-subhead">
          {icon}
          <span>{title}</span>
        </div>
        <div className="instance-chart-card-meta">
          <div className="instance-series-stats">
            <span className="tabular">{value}</span>
          </div>
        </div>
      </header>
      <div className="instance-chart-wrap">
        <ResponsiveContainer width="100%" height={height}>
          <LineChart
            data={points}
            margin={{ top: 4, right: 8, bottom: 4, left: 0 }}
          >
            <CartesianGrid stroke={gridColor} strokeWidth={1} />
            <XAxis
              dataKey="time"
              type="number"
              domain={["dataMin", "dataMax"]}
              scale="time"
              ticks={xTicks}
              tickFormatter={xTickFormatter}
              tick={{ fill: textColor, fontSize: 10 }}
              axisLine={false}
              tickLine={false}
              height={24}
            />
            <YAxis
              tick={{ fill: textColor, fontSize: 10 }}
              axisLine={false}
              tickLine={false}
              tickFormatter={yTickFormatter}
              tickCount={4}
              width={44}
            />
            <Tooltip
              content={
                <ChartTooltipContent
                  keys={keys}
                  colors={colors}
                  unit={unit}
                  rangeHours={rangeHours}
                />
              }
            />
            {keys.map((key, index) => (
              <Line
                key={key}
                type="linear"
                dataKey={key}
                stroke={colors[index] ?? colors[0]}
                strokeWidth={1}
                fill="none"
                dot={false}
                isAnimationActive={false}
                connectNulls={spanGaps ?? false}
                style={{ shapeRendering: "crispEdges", vectorEffect: "non-scaling-stroke" }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
});

export function LoadChart({
  uuid,
  hours,
  active = true,
}: {
  uuid: string;
  hours: number;
  active?: boolean;
}) {
  const queryHours = hours === 0 ? 1 : hours;
  const { data, isLoading } = useLoadRecords(uuid, queryHours, active);
  const isRealtime = hours === 0;
  const node = useNode(uuid, isRealtime && active);
  const { resolvedAppearance } = usePreferences();
  const { h } = { h: 148 };
  const [realtimePoints, setRealtimePoints] = useState<ChartPoint[]>([]);
  const [connectNulls, setConnectNulls] = useState(false);

  useEffect(() => {
    if (!active || !isRealtime || !node) return;
    const point = pointFromNode(node);
    setRealtimePoints((prev) => {
      const last = prev[prev.length - 1];
      if (last && Math.abs(last.time - point.time) < 1) return prev;
      return [...prev, point].slice(-600);
    });
  }, [active, isRealtime, node]);

  useEffect(() => {
    setRealtimePoints([]);
  }, [hours, uuid]);

  const historyPoints = useMemo<ChartPoint[]>(() => {
    const records = [...(data?.records ?? [])];
    const rawPoints = records
      .map((record) => ({
        time: toChartSeconds(record.time),
        cpu: record.cpu,
        ram: record.ram_total > 0 ? (record.ram / record.ram_total) * 100 : 0,
        swap: record.swap_total > 0 ? (record.swap / record.swap_total) * 100 : 0,
        disk: record.disk_total > 0 ? (record.disk / record.disk_total) * 100 : 0,
        diskBytes: record.disk,
        netIn: record.net_in,
        netOut: record.net_out,
        connections: record.connections,
        udp: record.connections_udp,
        process: record.process,
        load: record.load,
      }))
      .filter((point) => point.time > 0)
      .sort((a, b) => a.time - b.time);
    const sampled = downsamplePoints(rawPoints, getHistoryRenderLimit(hours));
    const filled = fillMissingMetricPoints(sampled);
    return interpolateMetricGaps(filled, LOAD_INTERPOLATE_KEYS);
  }, [data, hours]);

  const points = useMemo<ChartPoint[]>(() => {
    if (isRealtime) {
      const initial = historyPoints.slice(-REALTIME_HISTORY_SEED_LIMIT);
      const merged = [...initial, ...realtimePoints].sort((a, b) => a.time - b.time);
      const deduped = merged.filter((point, index, arr) => {
        const next = arr[index + 1];
        return !next || Math.abs(next.time - point.time) >= 1;
      });
      return deduped.slice(-REALTIME_SAMPLE_LIMIT);
    }
    return historyPoints;
  }, [historyPoints, isRealtime, realtimePoints]);

  if (isLoading) {
    return <section className="instance-panel h-[260px] animate-pulse" aria-busy />;
  }

  if (!points.length) {
    return (
      <InstancePanel title="负载图表">
        <div className="instance-empty">暂无负载历史数据</div>
      </InstancePanel>
    );
  }

  return (
    <InstancePanel
      title="负载图表"
      className="instance-chart-panel"
    >
      <div className="instance-chart-toolbar">
        <button
          type="button"
          className="instance-toggle-button instance-switch-button"
          data-active={connectNulls ? "true" : "false"}
          onClick={() => setConnectNulls((value) => !value)}
          aria-pressed={connectNulls}
        >
          <span className="instance-switch-copy">Connect gaps</span>
          <span className="instance-switch-track" aria-hidden>
            <span className="instance-switch-thumb" />
          </span>
          <span className="instance-switch-state">
            {connectNulls ? "On" : "Off"}
          </span>
        </button>
      </div>
      <div className="instance-chart-grid">
        <ChartCard
          icon={<Cpu size={13} />}
          title="CPU"
          value={
            isRealtime && node
              ? `${node.cpuPct.toFixed(2)}%`
              : `${(points[points.length - 1]?.cpu ?? 0).toFixed(2)}%`
          }
          points={points}
          keys={CPU_KEYS}
          colors={CPU_COLORS}
          height={h}
          resolvedAppearance={resolvedAppearance}
          rangeHours={hours}
          unit="%"
          spanGaps={connectNulls}
          axisKind="percent"
        />
        <ChartCard
          icon={<MemoryStick size={13} />}
          title="内存"
          value={
            isRealtime && node
              ? `${formatBytes(node.ramUsed)} / ${formatBytes(node.ramTotal)}`
              : data?.records.length
                ? `${formatBytes(data.records[data.records.length - 1]?.ram ?? 0)} / ${formatBytes(data.records[data.records.length - 1]?.ram_total ?? 0)}`
                : "—"
          }
          points={points}
          keys={MEMORY_KEYS}
          colors={MEMORY_COLORS}
          height={h}
          resolvedAppearance={resolvedAppearance}
          rangeHours={hours}
          unit="%"
          spanGaps={connectNulls}
          axisKind="percent"
        />
        <ChartCard
          icon={<HardDrive size={13} />}
          title="磁盘"
          value={
            isRealtime && node
              ? `${formatBytes(node.diskUsed)} / ${formatBytes(node.diskTotal)}`
              : data?.records.length
                ? `${formatBytes(data.records[data.records.length - 1]?.disk ?? 0)} / ${formatBytes(data.records[data.records.length - 1]?.disk_total ?? 0)}`
                : "—"
          }
          points={points}
          keys={DISK_KEYS}
          colors={DISK_COLORS}
          height={h}
          resolvedAppearance={resolvedAppearance}
          rangeHours={hours}
          unit="%"
          spanGaps={connectNulls}
          axisKind="percent"
        />
        <ChartCard
          icon={<Network size={13} />}
          title="网络"
          value={
            isRealtime && node
              ? `${formatTrafficRateLabel(node.netDown)} / ${formatTrafficRateLabel(node.netUp)}`
              : data?.records.length
                ? `${formatTrafficRateLabel(data.records[data.records.length - 1]?.net_in ?? 0)} / ${formatTrafficRateLabel(data.records[data.records.length - 1]?.net_out ?? 0)}`
                : "—"
          }
          points={points}
          keys={NETWORK_KEYS}
          colors={NETWORK_COLORS}
          height={h}
          resolvedAppearance={resolvedAppearance}
          rangeHours={hours}
          spanGaps={connectNulls}
          axisKind="network"
        />
        <ChartCard
          icon={<Workflow size={13} />}
          title="连接数"
          value={
            isRealtime && node
              ? `TCP ${node.connectionsTcp} / UDP ${node.connectionsUdp}`
              : data?.records.length
                ? `TCP ${Math.round(data.records[data.records.length - 1]?.connections ?? 0)} / UDP ${Math.round(data.records[data.records.length - 1]?.connections_udp ?? 0)}`
                : "—"
          }
          points={points}
          keys={CONNECTION_KEYS}
          colors={CONNECTION_COLORS}
          height={h}
          resolvedAppearance={resolvedAppearance}
          rangeHours={hours}
          spanGaps={connectNulls}
          axisKind="count"
        />
        <ChartCard
          icon={<Gauge size={13} />}
          title="进程"
          value={
            isRealtime && node
              ? node.process.toString()
              : data?.records.length
                ? Math.round(data.records[data.records.length - 1]?.process ?? 0).toString()
                : "—"
          }
          points={points}
          keys={PROCESS_KEYS}
          colors={PROCESS_COLORS}
          height={h}
          resolvedAppearance={resolvedAppearance}
          rangeHours={hours}
          spanGaps={connectNulls}
          axisKind="count"
        />
      </div>
    </InstancePanel>
  );
}
