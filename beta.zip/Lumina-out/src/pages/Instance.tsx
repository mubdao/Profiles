import { startTransition, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { InstanceOverview } from "@/components/instance/InstanceOverview";
import { NetworkChart } from "@/components/instance/NetworkChart";
import { LoadChart } from "@/components/instance/LoadChart";

import { usePublicConfig } from "@/hooks/usePublicConfig";

// 详情页时间选项: 实时、6h、12h、24h、7d、30d
const LOAD_FIXED_RANGES = [
  { label: "实时", value: 0 },
  { label: "6h",  value: 6 },
  { label: "12h", value: 12 },
  { label: "24h", value: 24 },
  { label: "7d",  value: 168 },
  { label: "30d", value: 720 },
];

// Ping页时间选项: 1h、6h、12h、24h、7d、30d
const PING_RANGES = [
  { label: "1h",  value: 1 },
  { label: "6h",  value: 6 },
  { label: "12h", value: 12 },
  { label: "24h", value: 24 },
  { label: "7d",  value: 168 },
  { label: "30d", value: 720 },
];

export function Instance() {
  const { uuid } = useParams<{ uuid: string }>();
  const { data: config } = usePublicConfig();
  const [chartType, setChartType] = useState<"load" | "ping">("load");
  const [loadHours, setLoadHours] = useState(0);
  const [pingHours, setPingHours] = useState(1);
  const chartControlsRef = useRef<HTMLDivElement | null>(null);

  const loadRanges = useMemo(
    () => {
      // If config limits history, filter fixed ranges
      const max = config?.record_preserve_time;
      if (!max || max <= 0) return LOAD_FIXED_RANGES;
      return LOAD_FIXED_RANGES.filter((r) => r.value === 0 || r.value <= max);
    },
    [config?.record_preserve_time],
  );

  const showPingChart = config?.theme_settings?.showPingChart !== false;

  const alignCharts = () => {
    const frame = window.requestAnimationFrame(() => {
      chartControlsRef.current?.scrollIntoView({
        behavior: "auto",
        block: "start",
      });
    });
    return () => window.cancelAnimationFrame(frame);
  };

  useEffect(() => {
    return alignCharts();
  }, [uuid]);

  useEffect(() => {
    if (!loadRanges.some((r) => r.value === loadHours)) {
      setLoadHours(loadRanges[0]?.value ?? 0);
    }
  }, [loadHours, loadRanges]);

  useEffect(() => {
    if (!showPingChart && chartType === "ping") {
      setChartType("load");
    }
  }, [chartType, showPingChart]);

  if (!uuid) return null;

  return (
    <div className="flex flex-col gap-5 py-2">
      <InstanceOverview uuid={uuid} onNodeReady={alignCharts} />
      <div ref={chartControlsRef} className="instance-chart-controls">
        {/* 详情 / 网络 切换 — 自适应宽度居中 */}
        <div className="instance-segmented">
          <button
            type="button"
            data-active={chartType === "load" ? "true" : "false"}
            onClick={() => startTransition(() => setChartType("load"))}
          >
            详情
          </button>
          {showPingChart && (
            <button
              type="button"
              data-active={chartType === "ping" ? "true" : "false"}
              onClick={() => startTransition(() => setChartType("ping"))}
            >
              网络
            </button>
          )}
        </div>

        {/* 详情时间范围 */}
        {chartType === "load" && (
          <div key="load-ranges" className="instance-segmented is-scrollable" style={{ width: "100%", maxWidth: 420 }}>
            {loadRanges.map((range) => (
              <button
                key={range.value}
                type="button"
                data-active={loadHours === range.value ? "true" : "false"}
                onClick={() => startTransition(() => setLoadHours(range.value))}
              >
                {range.label}
              </button>
            ))}
          </div>
        )}

        {/* Ping时间范围 */}
        {chartType === "ping" && showPingChart && (
          <div key="ping-ranges" className="instance-segmented is-scrollable" style={{ width: "100%", maxWidth: 420 }}>
            {PING_RANGES.map((range) => (
              <button
                key={range.value}
                type="button"
                data-active={pingHours === range.value ? "true" : "false"}
                onClick={() => startTransition(() => setPingHours(range.value))}
              >
                {range.label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="instance-chart-stage">
        <div
          className="instance-chart-view"
          hidden={chartType !== "load"}
          aria-hidden={chartType !== "load"}
        >
          <LoadChart uuid={uuid} hours={loadHours} active={chartType === "load"} />
        </div>
        <div
          className="instance-chart-view"
          hidden={chartType !== "ping"}
          aria-hidden={chartType !== "ping"}
        >
          {showPingChart ? (
            <NetworkChart
              uuid={uuid}
              hours={pingHours}
              active={chartType === "ping"}
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}
